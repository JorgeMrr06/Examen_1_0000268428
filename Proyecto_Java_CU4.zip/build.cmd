@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
if not exist build mkdir build
if not exist build\classes mkdir build\classes
if not exist dist mkdir dist
(for /r src %%f in (*.java) do (
  set "LUC_SOURCE=%%f"
  echo "!LUC_SOURCE:\=/!"
)) > build\sources.txt
set "LUC_JAVAC=javac"
set "LUC_JAR=jar"
if defined JAVA_HOME (
  set "LUC_JAVAC=%JAVA_HOME%\bin\javac.exe"
  set "LUC_JAR=%JAVA_HOME%\bin\jar.exe"
)
"%LUC_JAVAC%" -encoding UTF-8 --release 17 -d build\classes @build\sources.txt
if errorlevel 1 exit /b 1
"%LUC_JAR%" --create --file dist\PagoLuz.jar --main-class mx.itson.luz.app.AplicacionLuz -C build\classes .
if errorlevel 1 exit /b 1
echo Compilacion correcta: dist\PagoLuz.jar
