@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
call build.cmd
if errorlevel 1 exit /b 1
if not exist build\test-classes mkdir build\test-classes
(for /r tests %%f in (*.java) do (
  set "LUC_TEST=%%f"
  echo "!LUC_TEST:\=/!"
)) > build\tests.txt
javac -encoding UTF-8 --release 17 -cp build\classes -d build\test-classes @build\tests.txt
if errorlevel 1 exit /b 1
java -cp "build\classes;build\test-classes" mx.itson.luz.pruebas.PruebasLuz
if errorlevel 1 exit /b 1
java -Djava.awt.headless=true -cp "build\classes;build\test-classes" mx.itson.luz.pruebas.DemoSwingLuz evidencias
