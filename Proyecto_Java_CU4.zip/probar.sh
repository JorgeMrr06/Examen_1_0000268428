#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
sh build.sh
mkdir -p build/test-classes
find tests -name '*.java' > build/tests.txt
javac -encoding UTF-8 --release 17 -cp build/classes -d build/test-classes @build/tests.txt
java -cp 'build/classes:build/test-classes' mx.itson.luz.pruebas.PruebasLuz
java -Djava.awt.headless=true -cp 'build/classes:build/test-classes' mx.itson.luz.pruebas.DemoSwingLuz evidencias
