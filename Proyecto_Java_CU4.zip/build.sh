#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes dist
find src -name '*.java' > build/sources.txt
javac -encoding UTF-8 --release 17 -d build/classes @build/sources.txt
jar --create --file dist/PagoLuz.jar --main-class mx.itson.luz.app.AplicacionLuz -C build/classes .
echo 'Compilación correcta: dist/PagoLuz.jar'
